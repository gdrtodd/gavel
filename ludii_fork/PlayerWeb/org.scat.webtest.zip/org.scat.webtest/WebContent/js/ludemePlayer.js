/**
 * Included in a .html file with an explicitly named element, this application will create a canvas where you can play a ludii game.
 */
 
// GLOBAL CONSTANTS AND VARIABLES

const WIDGET_NAME = 'ludemePlayerWidget';
const WIDGET_WIDTH = 'data-width';
const WIDGET_HEIGHT = 'data-height';
const USERNAME_ATT = 'data-username';
const LUDEME_ATT = 'data-ludeme';
const RULESET_ATT = 'data-ruleset';
const INSTANCES_ATT = 'data-maxInstances';
const BOARD_CANVAS = 'ludemePlayerWidgetBoardDisplay';
const ANIMATION_CANVAS = 'ludemePlayerWidgetAnimations';
const MESSAGE_ID = 'ludemePlayerWidgetMessageText';

var ludemeName;
var rulesetName;
var username;
var maxInstances;
var isMobile = false;
var widget;
var dWidth;
var dHeight;
var messages;
var waiting = false;

/*
 * This function is called before anything else in this file during the parsing of the page, immediately after the player widget is defined
 * Here we add the canvas elements inside the widget 
 */
function initLudemePlayerWidget()
{
	var widget = document.getElementById(WIDGET_NAME);

	// Board display/background image layer	
	var boardLayer = document.createElement("canvas");
	boardLayer.setAttribute("id", BOARD_CANVAS);
	boardLayer.setAttribute("width", widget.getAttribute(WIDGET_WIDTH)+'px');
	boardLayer.setAttribute("height", widget.getAttribute(WIDGET_HEIGHT)+'px');
	widget.appendChild(boardLayer);
	
	var messages = document.createElement("p");
	messages.setAttribute("id", MESSAGE_ID);
	messages.setAttribute("style", "color:red; font-family:helvetica; font-size:20px");
	widget.appendChild(messages);
	
	// Animation layer / foreground
	var animationLayer = document.createElement("canvas");
	animationLayer.setAttribute("id", ANIMATION_CANVAS);
	animationLayer.setAttribute("width", widget.getAttribute(WIDGET_WIDTH)+'px');
	animationLayer.setAttribute("height", widget.getAttribute(WIDGET_HEIGHT)+'px');
	animationLayer.setAttribute("style", "position: absolute; left: 0; top: 0;");
	widget.appendChild(animationLayer);
}

 /*
  * Called on startup, to initialise everything
  * Note that the DOMContentLoaded event occurs after the page html has been loaded and rendered, but before all secondary assets, e.g. images have loaded.
  */
document.addEventListener("DOMContentLoaded", ludemePlayerStartup, false); 
//window.addEventListener("beforeunload", closeSessionOnUnload);
window.addEventListener("unload", closeSessionOnUnload);

/* 
 *	Confiormation message before exit
 */
function closeSessionOnUnload (event) 
{
	doClose();
//	(event || window.event).returnValue = null;
	return false;
	//var confirmationMessage = "\o/";
	//(event || window.event).returnValue = confirmationMessage; //Gecko + IE
	//return confirmationMessage;                            //Webkit, Safari, Chrome
}

function ludemePlayerStartup() 
{
    window.tabId = uuidv4(); // Create a unique session ID
    
	var widget = document.getElementById(WIDGET_NAME);

	ludemeName = widget.getAttribute(LUDEME_ATT);
	rulesetName = widget.getAttribute(RULESET_ATT);
	username = widget.getAttribute(USERNAME_ATT);
	maxInstances = widget.getAttribute(INSTANCES_ATT);
	if (!maxInstances || maxInstances < 0) maxInstances = 1;

	isMobile = navigator.userAgent.toLowerCase().match(/mobile/i);
	
	dWidth = Number(widget.getAttribute(WIDGET_WIDTH));
	dHeight = Number(widget.getAttribute(WIDGET_HEIGHT));
	messages = widget.getAttribute('data-messages');

	/*
	 * On with the plot - queu the initial request
	 */
	doRequest ('ApplyMoveGetAnimation?ludeme=' + ludemeName + 
		'&ruleset=' + rulesetName + 
		'&mode=first' + 
		'&username=' + username + 
		'&uuid=' + window.tabId + 
		'&width=' + dWidth + '&height=' + dHeight + 
		'&messages=' + messages +
		'&maxInstances=' +maxInstances);
}

function doRequest (url)
{
	// perform initial load
	var ajaxRequest = new XMLHttpRequest();
	ajaxRequest.onreadystatechange = function()
	{
		if (ajaxRequest.readyState != 4 || ajaxRequest.status != 200) return;
		applyAnimationParameters (ajaxRequest);		
	};

	//document.body.style.cursor = 'wait';
	document.getElementById(MESSAGE_ID).innerHTML = "Thinking...";
	setListenMode(false);
	
	ajaxRequest.open('GET', url);
	ajaxRequest.send();
}

/*
 * This function returns a unique identifier* for this tab
 * Well, not quite unique but the probability of collisions is small enough to be ignored
 */
function uuidv4() 
{
    var u='',m='xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx',i=0,rb=Math.random()*0xffffffff|0;
    while(i++<36) {
        var c=m[i-1],r=rb&0xf,v=c=='x'?r:(r&0x3|0x8);
        u+=(c=='-'||c=='4')?c:v.toString(16);rb=i%8==0?Math.random()*0xffffffff|0:rb>>4
    }
    return u;
}

/*
function log (message)
{
	var elt = document.getElementById('log');
	if (elt)
	{ 
		elt.innerHTML += '<br/>';
		elt.innerHTML += message;
	}
}
*/

var lastEvent = null;
function setListenMode (mode)
{
	var canvas = document.getElementById(ANIMATION_CANVAS);
	if (mode)
	{
		//log ("Listening");
		canvas.removeEventListener("mouseup", storeMouseClick);
		canvas.addEventListener("mouseup", doMouseClick, false);
	}
	else
	{
		//log ("Storing");
		canvas.removeEventListener("mouseup", doMouseClick);

		lastEvent = null;
		canvas.addEventListener("mouseup", storeMouseClick, false);
	}
}

function storeMouseClick(event)
{
	lastEvent = event;
	//log ('Stored x=' + event.offsetX + ', y=' + event.offsetY);
}

/*
 * User has clicked in the canvas area - pass the message to the back end and render the new background
 */
function doMouseClick(event)
{
	//log ('Click: x=' + event.offsetX + ', y=' + event.offsetY);
	doRequest('ApplyMoveGetAnimation?ludeme=' + ludemeName + 
		'&ruleset=' + rulesetName + 
		'&mode=click' + 
		'&username=' + username + 
		'&uuid=' + window.tabId + 
		'&x=' + event.offsetX + 
		'&y=' + event.offsetY);
}

/*
 * More animations are waiting for us
 */
function doContinuation()
{
	//log ('Continuation');
	doRequest('ApplyMoveGetAnimation?ludeme=' + ludemeName + 
		'&ruleset=' + rulesetName + 
		'&mode=continuation' + 
		'&username=' + username + 
		'&uuid=' + window.tabId);
}

/**
 * Clean up and exit
 */
function doClose()
{
	//log ('Close');
	
	var ajaxRequest = new XMLHttpRequest();
	ajaxRequest.open('POST', 'ApplyMoveGetAnimation?ludeme=' + ludemeName + 
		'&ruleset=' + rulesetName + 
		'&mode=close' + 
		'&username=' + username + 
		'&uuid=' + window.tabId);
	ajaxRequest.send();
}

function drawBackgroundImage(dataURL)
{
	var canvas = document.getElementById(BOARD_CANVAS);
	var ctx = canvas.getContext('2d');
				
	var img = new Image;
	img.onload = function() { ctx.drawImage(img,0,0,img.width,img.height); };
	img.src = dataURL;
}

/*
 * Called after a user interaction to get the animation(s) associated with the event
 */
function applyAnimationParameters(ajaxRequest)
{
	var response = ajaxRequest.responseText;
				
	var xmlDoc;
	if (window.DOMParser) {
	    var parser = new DOMParser();
	    xmlDoc = parser.parseFromString(response, "application/xml");
	} else {// Internet Explorer
		xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
	    xmlDoc.async = false;
	    xmlDoc.loadXML(response);
	}

	// Set the message text (if any)
	var messageText = xmlDoc.getElementsByTagName("message")[0].getAttribute("value");
	document.getElementById(MESSAGE_ID).innerHTML = messageText;			

	// Display the pre-animation background
	var bgArray = xmlDoc.getElementsByTagName("preAnimationBackground");
	if (bgArray.length > 0)
	{
		var preImgDataUrl = "data:image/png;base64,"+bgArray[0].textContent;
		drawBackgroundImage(preImgDataUrl);
	}
	
	// Clear anything in the animation layer
	var canvas = document.getElementById(ANIMATION_CANVAS);
	var ctx = canvas.getContext('2d');
	ctx.clearRect(0, 0, canvas.width,canvas.height);

	// Get the final background image		
	var postArray = xmlDoc.getElementsByTagName("postAnimationBackground");
	if (postArray.length==0) return;
	
  	var postImgDataUrl = "data:image/png;base64,"+postArray[0].textContent;

	var durationMs = Number(xmlDoc.getElementsByTagName("durationMs")[0].getAttribute("value"));
	var animationType = xmlDoc.getElementsByTagName("animationType")[0].getAttribute("value");
		
	var txtCont = xmlDoc.getElementsByTagName("isContinuation")[0].getAttribute("value");
   	var isContinuation = String(txtCont).toLowerCase() == "true";
		
    var files = xmlDoc.getElementsByTagName("sprite");
	//document.getElementById(MESSAGE_ID).innerHTML = "cleanup! isContinuation="+isContinuation+", sprites="+files.length+", animationType="+animationType;
	
	if (files.length==0)
	{
		drawBackgroundImage(postImgDataUrl);
		ctx.clearRect(0, 0, canvas.width,canvas.height);
		cleanupAnimation(isContinuation);
		return;
	}
	
	// else
	var animationCount = files.length;
	for (idx = 0; idx < files.length; idx++)
	{
    	var fromX = Number(files[idx].getAttribute("from.x"));
	   	var fromY = Number(files[idx].getAttribute("from.y"));
						    	
    	var toX = Number(files[idx].getAttribute("to.x"));
    	var toY = Number(files[idx].getAttribute("to.y"));
						    	
    	//var imgSrc = document.createElement("img");
    	var imgDataUrl = "data:image/png;base64,"+files[idx].textContent;
    	//imgSrc.setAttribute("src", imgDataUrl);
						    	
		var img = new Image;
		img.onload = function() 
		{ 
			var starttime = null;
	    	switch (animationType)
	    	{
			case 'PULSE':
				function pulse(timestamp) 
				{
					if (!starttime) starttime = timestamp;
					var runtime = timestamp - starttime;
					var lambda = runtime / durationMs;

					ctx.clearRect(0, 0, canvas.width,canvas.height);

					if (runtime < durationMs) {
						ctx.globalAlpha = Math.sin(2 * Math.PI * lambda) * 0.5 + 0.5;
						ctx.drawImage(img, toX, toY);
						window.requestAnimationFrame(pulse);												
					} else {
						drawBackgroundImage(postImgDataUrl);
						if (--animationCount==0) cleanupAnimation (isContinuation);
					}
				}
				window.requestAnimationFrame(pulse);
				break;

			case 'DRAG':
				function drag(timestamp) 
				{
					if (!starttime) starttime = timestamp;
					var runtime = timestamp - starttime;
					var lambda = runtime / durationMs;

					ctx.clearRect(0, 0, canvas.width,canvas.height);
					if (runtime < durationMs) {
						ctx.drawImage(img, fromX+lambda*(toX-fromX), fromY+lambda*(toY-fromY));
						window.requestAnimationFrame(drag);												
					} else {
						drawBackgroundImage(postImgDataUrl);
						if (--animationCount==0) cleanupAnimation (isContinuation);
					}
				}
				window.requestAnimationFrame(drag);
				break;

			case 'NONE':
				ctx.drawImage(img, toX, toY);
				if (--animationCount==0) cleanupAnimation (isContinuation);
				break;
			}
		};
		img.setAttribute("src", imgDataUrl)
	}
}

function cleanupAnimation (isContinuation)
{
	//document.body.style.cursor = 'default';
	setListenMode(true);

	if (lastEvent) 
	{
		var tempEvent = lastEvent;
		lastEvent = null;
		doMouseClick(tempEvent);
	}
	else if (isContinuation) 
	{
		doContinuation();	
	}	
}