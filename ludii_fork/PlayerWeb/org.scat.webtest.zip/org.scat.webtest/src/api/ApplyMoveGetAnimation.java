package api;

import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Map;
import java.util.Base64.Encoder;
import java.util.Date;
import java.util.LinkedHashMap;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import app.WebApp;
import app.display.utils.WebPlayerFunctions;
import app.display.utils.DisplayParameters;
import app.move.animation.AnimationType;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


/**
 * Servlet implementation class AnimationParameters.
 * Returns the animation parameters after making a move
 */
@WebServlet("/ApplyMoveGetAnimation")
public final class ApplyMoveGetAnimation extends HttpServlet 
{
	private static final String SESSION_EXPIRED_MESSAGE = "Sorry, this session has expired.";
	private static final long serialVersionUID = 1L;
	private static final int NOT_SUPPLIED = -1;
	private static final String FIRST = "first";
	private static final String CLOSE = "close";
	private static final String CLICK = "click";
	private static final String CONTINUATION = "continuation";
	private static final String ALL_APPS = "allApps";
	
	@Override
	protected void doGet (final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("application/xml");
		response.setHeader("Cache-Control", "private, no-cache, must-revalidate");		// Set standard HTTP/1.1 no-cache headers.
		response.setHeader("Pragma", "no-cache");										// Set standard HTTP/1.0 no-cache header.
		
		try {
			final String mode = request.getParameter("mode");
			final String ludeme = request.getParameter("ludeme");
			final String ruleset = request.getParameter("ruleset");
			final String uuid = request.getParameter("uuid");
			final String username = request.getParameter("username");
			final String appId = Utils.appId(uuid);

			log(appId, "ApplyMoveGetAnimation.doGet invoked for user "+username);

			final HttpSession session = request.getSession();
			WebApp app = null;
	
			switch (mode)
			{
			case FIRST:
				log(appId, "Creating new instance of " + ludeme + ":" + ruleset);

				final Map<String, String> map = Utils.sessionParametersToMap(request);
				log(appId, "Initialising the app with "+map);

				final int maxInstances = toInt(request.getParameter("maxInstances"));
				log(appId, "Max. concurrent instances: "+maxInstances);

				app = new WebApp();	
				app.createPlayerApp(app, map);
				
				storeWebAppInstance (session, appId, app, maxInstances);
				break;

			case CLICK:
				final int x = toInt(request.getParameter("x"));
				final int y = toInt(request.getParameter("y"));

				log(appId, "Click ("+x+","+y+")");

				app = getWebAppInstance (session, appId);
				if (app == null)
				{
					// Happens if and only if the user has too many active sessions
					sessionTimeoutResponse(appId, response);
					return;
				}

				final Point newPoint = new Point(x,y);
				WebPlayerFunctions.clickedPoint(app, newPoint);
				break;

			case CONTINUATION:
				log(appId, "Continuation");

				app = getWebAppInstance (session, appId);
				if (app == null)
				{
					// Happens if and only if the user has too many active sessions
					sessionTimeoutResponse(appId, response);
					return;
				}
				break;

			case CLOSE:
				log(appId, "Close session");
				removeWebAppInstance (session, appId);
				return;

			default:
				throw new UnsupportedOperationException("mode must be one of {first,click,continuation,close} but was "+mode);
			}
			
			log(appId, "Rendering... ");
			
			final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			final DocumentBuilder builder = factory.newDocumentBuilder();
			final Document doc = builder.newDocument();

			final Element root = doc.createElement("AnimationParameters");
			doc.appendChild(root);

			final DisplayParameters displayParams = WebPlayerFunctions.getDisplayParameters(app);

			final String message = displayParams.message();
			final Element msg = doc.createElement("message");
			root.appendChild(msg);
			msg.setAttribute("value", message);

			final boolean isContinuation = displayParams.continuation();
			final Element cont = doc.createElement("isContinuation");
			root.appendChild(cont);
			cont.setAttribute("value", Boolean.toString(isContinuation));
			log(appId, "isContinuation: "+isContinuation);
			final Encoder encoder = Base64.getMimeEncoder();
			
			final BufferedImage preImage = displayParams.preAnimationBoardImage();
			final BufferedImage postImage = displayParams.postAnimationBoardImage();
			
			final Element pre = doc.createElement("preAnimationBackground");
			root.appendChild(pre);
			addMimedImageToNode(encoder, preImage, pre);
			
			final Element post = doc.createElement("postAnimationBackground");
			root.appendChild(post);
			addMimedImageToNode(encoder, postImage, post);
			
			final app.move.animation.AnimationParameters ap = displayParams.animationParameters();
			
			if (ap == null)
			{
				log(appId, "No animation available.");
				
				final Element duration = doc.createElement("durationMs");
				root.appendChild(duration);
				duration.setAttribute("value", Long.toString(0L));

				final Element type = doc.createElement("animationType");
				root.appendChild(type);
				type.setAttribute("value", AnimationType.NONE.name());
			}
			else
			{
				if (ap.pieceImages.size()==0) log(appId, "Empty animation list returned.");
					
				final Element duration = doc.createElement("durationMs");
				root.appendChild(duration);
				duration.setAttribute("value", Long.toString(ap.animationTimeMs));

				final Element type = doc.createElement("animationType");
				root.appendChild(type);
				type.setAttribute("value", ap.animationType.name());

				for (int idx=0; idx < ap.pieceImages.size(); idx++)
				{
					final Point from = ap.fromLocations.get(idx);
					final Point to = ap.toLocations.get(idx);
					final BufferedImage img = ap.pieceImages.get(idx);
	
					final Element node = doc.createElement("sprite");
					root.appendChild(node);
					node.setAttribute("from.x", Integer.toString(from.x));
					node.setAttribute("from.y", Integer.toString(from.y));
					node.setAttribute("to.x", Integer.toString(to.x));
					node.setAttribute("to.y", Integer.toString(to.y));
					
					addMimedImageToNode(encoder, img, node);
				}
			}
			
			final TransformerFactory transformerFactory = TransformerFactory.newInstance();
			final Transformer transf = transformerFactory.newTransformer();
			transf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			transf.setOutputProperty(OutputKeys.INDENT, "yes");
			transf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

			final DOMSource source = new DOMSource(doc);

			try (PrintWriter writer = response.getWriter())
			{
				final StreamResult console = new StreamResult(writer);
				transf.transform(source, console);
			}
			
		} 
		catch (Exception e) 
		{
			throw new ServletException(e);
		}
	}
	
	private void sessionTimeoutResponse(final String appId, final HttpServletResponse response) throws IOException, TransformerException, ParserConfigurationException 
	{
		log(appId, "Generating session timeout response... ");
		
		final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		final DocumentBuilder builder = factory.newDocumentBuilder();
		final Document doc = builder.newDocument();

		final Element root = doc.createElement("AnimationParameters");
		doc.appendChild(root);

		final String message = SESSION_EXPIRED_MESSAGE;
		final Element msg = doc.createElement("message");
		root.appendChild(msg);
		msg.setAttribute("value", message);

		final boolean isContinuation = false;
		final Element cont = doc.createElement("isContinuation");
		root.appendChild(cont);
		cont.setAttribute("value", Boolean.toString(isContinuation));
		
		final Element duration = doc.createElement("durationMs");
		root.appendChild(duration);
		duration.setAttribute("value", Long.toString(0L));

		final Element type = doc.createElement("animationType");
		root.appendChild(type);
		type.setAttribute("value", AnimationType.NONE.name());
		
		final TransformerFactory transformerFactory = TransformerFactory.newInstance();
		final Transformer transf = transformerFactory.newTransformer();
		transf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		transf.setOutputProperty(OutputKeys.INDENT, "yes");
		transf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

		final DOMSource source = new DOMSource(doc);

		try (final PrintWriter writer = response.getWriter())
		{
			final StreamResult console = new StreamResult(writer);
			transf.transform(source, console);
		}		
	}

	@SuppressWarnings("unchecked")
	private static final void removeWebAppInstance (final HttpSession session, final String appId) throws ServletException
	{
		synchronized (session) 
		{
			final LinkedHashMap<String,WebApp> map = (LinkedHashMap<String, WebApp>) session.getAttribute(ALL_APPS);
			if (map==null) return;
			map.remove(appId);
			log(appId, "Active sessions: "+map.size());
		}
	}

	@SuppressWarnings("unchecked")
	private static final WebApp getWebAppInstance (final HttpSession session, final String appId) throws ServletException
	{
		synchronized (session) 
		{
			final LinkedHashMap<String,WebApp> map = (LinkedHashMap<String, WebApp>) session.getAttribute(ALL_APPS);
			if (map==null) throw new ServletException("Game has been improperly initialised");

			log(appId, "Active sessions: "+map.size());
			return map.get(appId);
		}
	}

	@SuppressWarnings("unchecked")
	private final void storeWebAppInstance (final HttpSession session, final String appId, final WebApp webApp, final int maxInstances)
	{
		synchronized (session) 
		{
			LinkedHashMap<String,WebApp> map = (LinkedHashMap<String, WebApp>) session.getAttribute(ALL_APPS);
			
			if (map==null) // Lazy initialisation 
			{
				map = new LinkedHashMap<String,WebApp>() 
				{
					private static final long serialVersionUID = 1L;
				     protected boolean removeEldestEntry(Map.Entry<String,WebApp> eldest) 
				     {
				        return size() > maxInstances;
				     }	
				};
				session.setAttribute(ALL_APPS, map);
			}
			map.put(appId, webApp);
			log(appId, "Active sessions: "+map.size());
		}
	}		

	private final void addMimedImageToNode (
			final Encoder encoder, 
			final BufferedImage img, 
			final Element node)
			throws IOException 
	{
		final ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(img, "png", baos);
		final String mime = encoder.encodeToString(baos.toByteArray());
		node.setTextContent(mime);
	}

	private static final void log (final String appId, final String message)
	{
		final String timeStamp = new SimpleDateFormat().format( new Date() );
		System.out.println (timeStamp + " | " + ApplyMoveGetAnimation.class.getName() + " | " + appId + " | " + message);
	}
	
	private static final int toInt(final String parameter) 
	{
		if (parameter==null || parameter.isEmpty()) return NOT_SUPPLIED;
		try { 
			return (int) Double.parseDouble(parameter);
		} catch (final Exception e) {
			e.printStackTrace();
		}
		return NOT_SUPPLIED;
	}

	@Override
	protected void doPost (final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
	{
		// We can get here only if the browser uses the navigator.sensBeacon() method
		
		final HttpSession session = request.getSession();

		final String uuid = request.getParameter("uuid");
		final String appId = Utils.appId(uuid);

		log(appId, "ApplyMoveGetAnimation.doPost invoked");
		log(appId, "Close session");
		
		removeWebAppInstance (session, appId);
	}

	@Override
	protected void doDelete (final HttpServletRequest req, final HttpServletResponse resp) throws ServletException, IOException 
	{
		throw new UnsupportedOperationException("Correct usage: GET AnimationParameters");
	}

	@Override
	protected void doPut (final HttpServletRequest req, final HttpServletResponse resp) throws ServletException, IOException 
	{
		throw new UnsupportedOperationException("Correct usage: GET AnimationParameters");
	}
}