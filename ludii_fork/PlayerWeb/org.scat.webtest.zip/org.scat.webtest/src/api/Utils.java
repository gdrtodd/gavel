package api;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

public final class Utils 
{
	private static final String APP_KEY = "playLudemeSimpleApp";
	private static final String[] KEYS = {
		"ludeme",	
		"ruleset",
		"width",
		"height",
		"messages",
		"username"
	};
	
	private Utils() { /* Static methods only */ }
	
	/**
	 * @param request
	 * @return map containing parameters from the HTTP request, for passing to the SimpleApp.
	 */
	public static final Map<String,String> sessionParametersToMap (final HttpServletRequest request)
	{
		final Map<String,String> params = new HashMap<>();
		
		for (final String key : KEYS)
			params.put(key, request.getParameter(key));
		
		return params;
	}
	
	/**
	 * @param uuid
	 * @return application ID
	 */
	public static final String appId(final String uuid) { return Utils.APP_KEY+"-"+uuid; }
}
